package user;

import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;
import java.io.*;

public class ChocoTag extends SimpleTagSupport {
   private String texture;

   public void setTexture(String texture) {
      this.texture = texture;
   }

   public void doTag() throws JspException, IOException {

       JspWriter out = getJspContext().getOut();

       		if (texture.equals("chewy")) {
       			out.println("FiveStar, BarOne");
       		}
       		else if (texture.equals("crunchy")) {

             	out.println("Munch. KitKat");
       		}

  
   }

}