package pack;

public class ValidateBean implements java.io.Serializable
{
  String user;
  String pass;
  String gender;
  int age;
  String bdate;
  String email;
  String[] hobbies;
 
  public ValidateBean( ) {   }
 
  public void setUser(String user)  
  {
    this.user = user;
  }
  public String getUser( )
  {
    return user;
  }
 
  public void setPass(String pass)  
  {
    this.pass = pass;
  }

  public String getPass( )
  {
    return pass;
  }

  public void setGender(String gender)  
  {
    this.gender = gender;
  }
  public String getGender( )
  {
    return gender;
  }

  public void setAge(int age)  
  {
    this.age = age;
  }
  public int getAge( )
  {
    return age;
  }
 
  public void setBdate(String bdate)  
  {
    this.bdate = bdate;
  }
  public String getBdate( )
  {
    return bdate;
  }

  public void setEmail(String email)  
  {
    this.email = email;
  }
  public String getEmail( )
  {
    return email;
  }


  public String[] getHobbies( )
  {
    return hobbies;
  }

  public void setHobbies(String[] hobbies)  
  {
    this.hobbies = hobbies;
  }
 


 
  public String validate(String s1,String s2)
  {
    if(s1.equals(user) && s2.equals(pass))
      return "VALID";
    else
     return "INVALID";
   }
}


