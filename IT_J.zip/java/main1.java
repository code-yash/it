import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

abstract class Stack
{
  int top;
Stack()
  {
    this.top = -1;
  }
  abstract void push(int paramInt);
  abstract int pop();
  abstract void display();
}

class dynamicStack
  extends Stack
{
  ArrayList<Integer> arr;
dynamicStack()
  {
    this.arr = new ArrayList();
  }
  void push(int paramInt)
  {
this.arr.add(++this.top, Integer.valueOf(paramInt));
  }
  int pop()
  {
    if (this.top == -1) {
      return -1;
    }
    return ((Integer)this.arr.remove(this.top--)).intValue();
  }
  void display()
  {
    System.out.print("The Stack is : ");
    for (int i = 0; i <this.arr.size(); i++) {
      System.out.print(this.arr.get(i) + " ");
    }
    System.out.println();
  }
}

class staticStack
  extends Stack
{
int[] arr;
  int size;
staticStack(int paramInt)
  {
this.size = paramInt;
    this.arr = new int[this.size];
  }
  void push(int paramInt)
  {
    if (this.top == this.size - 1) {
      System.out.println("overflow");
    } else {
      this.arr[(++this.top)] = paramInt;
    }
  }
  int pop()
  {
    if (this.top == -1) {
      return -1;
    }
    return this.arr[(this.top--)];
  }
  void display()
  {
    System.out.print("The Stack is : ");
    for (int i = 0; i <= this.top; i++) {
      System.out.print(this.arr[i] + " ");
    }
    System.out.println();
  }
}


public class main1
{
  public static void main(String[] paramArrayOfString)
  {
    Scanner localScanner = new Scanner(System.in);
    System.out.println("Enter");
    System.out.println("1.staticStack");
    System.out.println("2.dynamicStack");
    System.out.println("3.Exit");
    int m = localScanner.nextInt();
    switch (m)
    {
    case 1: System.out.println("Enter array size");
      int i3 = localScanner.nextInt();
      staticStack localstaticStack = new staticStack(i3);
      System.out.println("Enter");
      System.out.println("1.Push");
      System.out.println("2.Pop");
      System.out.println("3.Display");
      int i4;
      do
      {
        System.out.println("Enter your choice");
        int i = localScanner.nextInt();
        switch (i)
        {
        case 1: 
          System.out.println("Enter a number to be pushed into the stack");
          int j = localScanner.nextInt();
          localstaticStack.push(j);
          break;
        case 2: 
          int k = localstaticStack.pop();
          if (k == -1) {
            System.out.println("Underflow");
          } else {
            System.out.println("Number popped =" + k);
          }
          break;
        case 3: 
          localstaticStack.display();
        }
        System.out.println("Enter 0 if you want to continue");
        i4 = localScanner.nextInt();
      } while (i4 == 0);
      break;
    case 2: 
      dynamicStack localdynamicStack = new dynamicStack();
      System.out.println("Enter");
      System.out.println("1.Push");
      System.out.println("2.Pop");
      System.out.println("3.Display");
      for (;;)
      {
        System.out.println("Enter your choice");
        int n = localScanner.nextInt();
        switch (n)
        {
        case 1: 
          System.out.println("Enter a number to be pushed into the stack");
          int i1 = localScanner.nextInt();
          localdynamicStack.push(i1);
          break;
        case 2: 
          int i2 = localdynamicStack.pop();
          if (i2 == -1) {
            System.out.println("Underflow");
          } else {
            System.out.println("Number popped =" + i2);
          }
          break;
        case 3: 
          localdynamicStack.display();
        }
        System.out.println("Enter 0 if you want to continue");
        int i5 = localScanner.nextInt();
        if (i5 != 0) {
          break;
        }
      }
    }
  }
}