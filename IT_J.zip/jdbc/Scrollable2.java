import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
 
public class Scrollable2 {
 
    public static void main(String[] a){
         
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.
                getConnection("jdbc:mysql://localhost/Emp","root","hrc");
            st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = st.executeQuery("SELECT FName,LName FROM Employee");
            System.out.println("ResultSet Curson is at before first: "+rs.isBeforeFirst());
            while(rs.next()){
                System.out.println("\n"+ rs.getString(1)+"   "+rs.getString(2));
            }
            //now result set cursor reached the last position
            System.out.println("Is After Last: "+rs.isAfterLast()+"\n");
            while(rs.previous()){
                System.out.println(rs.getString(1)+"   "+rs.getString(2));
            }
        } catch (ClassNotFoundException e) {
            //  Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            //  Auto-generated catch block
            e.printStackTrace();
        } finally{
            try{
                if(rs != null) rs.close();
                if(st != null) st.close();
                if(con != null) con.close();
} catch(Exception ex){}
        }
    }
}
