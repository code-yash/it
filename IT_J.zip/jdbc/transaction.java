import java.sql.*;
import java.util.scanner;

public class TransactionDemo {

   public static void main(String[] args)

    connection myConn = null;
Stataement myStat = null;

 try{
      // 1. Get a connection to database
      myConn =DriverManager.getConnection{"jdbc:mysql://  	localhost/Emp","root","hrc");

	//Turn off auto commit
	 myConn.setAutoCommit(false);

      
	
