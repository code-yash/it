import java.sql.*;

public class Updatable {
 
    public static void main(String[] a){


	Statement DataRequest=null, DataRequest2=null;
	ResultSet Results=null,Results2=null;
	Connection Db=null;
	try {
		Class.forName( "com.mysql.jdbc.Driver");
		Db = DriverManager.getConnection("jdbc:mysql://localhost/Emp","root","hrc");
	    }
       catch (ClassNotFoundException error) {
          System.err.println("Unable to load the JDBC/ODBC bridge." + error);
          System.exit(1);
       }
     catch (SQLException error) {
          System.err.println("Cannot connect to the database." + error);
          System.exit(2);
      }
    try {
          String query = "SELECT id, FName,LName FROM Employee WHERE FName = 'Rajiv' and LName = 'RS'";
          DataRequest = Db.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
          Results = DataRequest.executeQuery(query);
        }
    catch ( SQLException error ){
        System.err.println("SQL error." + error);
        System.exit(3);
      }

     
   try {
        boolean Records = Results.next();
       
        if (!Records ) 
         {
            System.out.println("No data returned");
            System.exit(4);
          }
         Results.updateString ("LName", "RR");
         Results.updateRow();
       
       String query2= "Select * from   Employee";       
         DataRequest2 = Db.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
         Results2 = DataRequest2.executeQuery (query2);
         while(Results2.next()){
                System.out.println(Results2.getString(3)+"   "+Results2.getString(4));
            }
 
         DataRequest.close();
         DataRequest2.close();
}
    catch (SQLException error ) {
        System.err.println("Data display error." + error);
         System.exit(5);
       }finally{
              try{
                   if(Results != null) Results.close();
                   if(Results != null) Results.close();
                   if(Results != null) Results.close();
              } catch(Exception ex){}
             }
    }
}

