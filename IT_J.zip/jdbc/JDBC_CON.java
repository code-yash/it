import java.io.*;
import java.sql.*;

public class JDBC_CON {
    static final String url = "jdbc:mysql://localhost/Employee";
    static final String userID = "root";
    static final String password = "hrc";

public static void main(String[] args) {    
    Statement DataRequest;
    ResultSet Results;
    Connection Db;
try {
    Class.forName( "com.mysql.jdbc.Driver");
    Db = DriverManager.getConnection(url,userID,password);
  
 

     String query = "SELECT * FROM test";
     DataRequest = Db.createStatement();
     Results = DataRequest.executeQuery (query);

    while(Results.next()){
//Retrieve by column name
     String first = Results.getString("firstName");
     String last = Results.getString("lastName");
     String favColor = Results.getString("favColor");
     String gender = Results.getString("gender");
     int luckyNumber = Results.getInt("luckyNumber");
     String empId = Results.getString("empId");
//Display values

    System.out.print("FirstName: " + first);
    System.out.print(", LastName: " + last);
    System.out.print(", Favorite Color: " + favColor);
    System.out.print(", gender: " + gender);
    System.out.print(", ID: " + empId);
    System.out.println(", Lucky Number: " + luckyNumber);
    }

     Results.close();
     DataRequest.close();
     Db.close();
    }catch ( SQLException error ){
      System.err.println("SQL error." + error);
      System.exit(3);
      }catch (ClassNotFoundException error) {
       System.err.println("Unable to load the JDBC DRIVER." + error);
        System.exit(1);
       }

     
  }
}
