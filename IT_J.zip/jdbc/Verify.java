import java.util.Date;
import java.io.*;
import java.util.Scanner;
public class Verify{
   public static void main(String[] args)
   {
    String email;
    System.out.println("Enter email: \n");
    Scanner sc=new Scanner(System.in);
    email=sc.next();
    if (email.indexOf('@')< 0 )
         System.out.println("Invalid email ! It  must contain \'@\'");
    if(email.indexOf('@')==0)
         System.out.println("Invalid email ! It  cannot start with \'@\'");
    if(email.indexOf('@')==(email.length()-1))
         System.out.println("Invalid email ! It  cannot end with \'@\'");

    if (email.indexOf('.')<= 0 )
         System.out.println("Invalid email!! It must contain \'.\'");
    if(email.indexOf('.')==0)
         System.out.println("Invalid email ! It  cannot start with \'.\'");
    if(email.indexOf('.')==(email.length()-1))
         System.out.println("Invalid email ! It  cannot end with \'.\'");

   
   }}
