import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Scrollable 
{

public static void main(String[] args) 
{
final String url = "jdbc:mysql://localhost/Emp";
final String userID = "root";
final String password = "hrc";
String printrow;
String FirstName;
String LastName;
Statement DataRequest=null;
ResultSet Results=null;
Connection Db=null;
 
try {
Class.forName("com.mysql.jdbc.Driver");
Db = DriverManager.getConnection(url,userID,password);
}
catch (ClassNotFoundException error) {
System.err.println("Unable to load the JDBC " + error);
System.exit(1);
}
catch (SQLException error) {
System.err.println("Cannot connect to the database." + error);
System.exit(2);
}

try {
   String query = "SELECT FName,LName FROM Employee";
   DataRequest = Db.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
   Results = DataRequest.executeQuery(query);
  }
  catch ( SQLException error ){
    System.err.println("SQL error." + error);
    System.exit(3);
  }

try { 
System.out.println("ResultSet Cursor is at before first: "+Results.isBeforeFirst());

boolean Records = Results.next();
System.out.println("next is :" + Records);
if(!Records) {
System.out.println("No data returned");
System.exit(4);
}
//do {
Results.first();
System.out.println("ResultSet Cursor is at first: "+ Results.getString(1)+" " + Results.getString (2));
Results.last();
System.out.println("ResultSet Cursor is at last: "+ Results.getString(1)+" " + Results.getString (2));
Results.previous();
System.out.println("ResultSet Cursor is at 2nd last: "+ Results.getString(1)+" " + Results.getString (2));
Results.absolute(4);
System.out.println("ResultSet Cursor is at 4th record: "+ Results.getString(1)+" " + Results.getString (2));
Results.relative(-2);
System.out.println("ResultSet Cursor is now 2 records before : "+ Results.getString(1)+" " + Results.getString (2));
Results.relative(3);
System.out.println("ResultSet Cursor has moved 3 records ahead: "+ Results.getString(1)+" " + Results.getString (2));
FirstName = Results.getString ( 1 ) ;
LastName = Results.getString ( 2 ) ;
printrow = FirstName + " " + LastName;
System.out.println(printrow);

//} while(Results.next());
DataRequest.close();
}
catch (SQLException error ) {
error.printStackTrace();
System.err.println("Data display error." + error);
System.exit(5);
}finally{
            try{
                if(Results!= null) Results.close();
                if(DataRequest != null) DataRequest.close();
                if(Db != null) Db.close();
               } catch(Exception ex){}
        }
}
}
