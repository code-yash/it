package user;

import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;
import java.io.*;

public class StringReverseTag extends SimpleTagSupport {
   private String input;

   public void setInput(String input) {
      this.input = input;
   }

   public void doTag() throws JspException, IOException {

       JspWriter out = getJspContext().getOut();

       		if (input != null) {
       			out.println("Result: " + reverse(input));
       		}
    

  
   }

   private String reverse(String input) {

      String result = "";
      char[] resultA = input.toCharArray();

      for (int i = input.length()-1; i>=0; --i) {
          
          result += resultA[i];
      }

      return result;
   }

}