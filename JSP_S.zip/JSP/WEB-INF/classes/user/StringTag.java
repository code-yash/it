package user;

import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;
import java.io.*;

public class StringTag extends SimpleTagSupport {
   private String input;
   private int start;
   private int end;

   public void setInput(String input) {
      this.input = input;
   }
   public void setStart(int start) {
      this.start = start;
   }
   public void setEnd(int end) {
      this.end = end;
   }

   public void doTag() throws JspException, IOException {

       JspWriter out = getJspContext().getOut();

      if (end != 0) {

        out.println("Result: " + input.substring(start, end+1));
  
      }
       
   }

}